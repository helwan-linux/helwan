# lang/ar.py
lang = {
    "title": "مدير عمليات حلوان",
    "language": "اللغة",
    "search": "بحث...",
    "refresh": "تحديث",
    "kill": "إنهاء",
    "tab_performance": "الأداء",
    "tab_processes": "العمليات",
    "tab_system_info": "معلومات النظام",
    "tab_network_sensors": "الشبكة والمستشعرات",
    "tab_network_monitor": "مراقبة الشبكة",
    "tab_about": "حول البرنامج",
    "columns": ["المعرف", "الاسم", "المعالج %", "الذاكرة %", "المستخدم"],
    "start_time_col": "وقت البدء",  # Added
    "path_col": "المسار",           # Added
    "threads_col": "الخيوط",         # Added
    "about_text": (
        "مدير عمليات حلوان\n"
        "الإصدار 1.0\n"
        "تم التطوير بواسطة فريق SMA Coding\n\n"
        "يوفر هذا البرنامج مراقبة لحظية لموارد النظام مثل المعالج والذاكرة والعمليات والشبكة،\n"
        "ويدعم تعدد اللغات وميزات متقدمة لراحة المستخدم."
    ),
    "select_process_warning": "يرجى تحديد عملية لإنهاءها.",
    "invalid_process_warning": "تم تحديد عملية غير صالحة.",
    "no_such_process_error": "العملية لم تعد موجودة.",
    "permission_denied_error": "تم رفض الإذن بإنهاء هذه العملية. حاول التشغيل كمسؤول/جذر.",
    "kill_error": "حدث خطأ أثناء محاولة إنهاء العملية: {e}"
}
